export class CreateChunkDto {
  chunkInterval: number;
}
